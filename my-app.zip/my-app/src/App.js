import logo from './logo.svg';
import './App.css';
import Toppage1 from './landingpage/toppage1';
import Page2 from './landingpage/page2';
import Page3 from './landingpage/page3';
import Page4 from './landingpage/page4';
import Page5 from './landingpage/page5';
import Page6 from './landingpage/page6';
import Page7 from './landingpage/page7';
import Page8 from './landingpage/page8';
import Page9 from './landingpage/page9';
import Page10 from './landingpage/page10';
import Footer from './landingpage/footer';


function App() {
  return (
    <>
   <Toppage1/>
   <Page2/>
   <Page3/>
   {/* <Page4/> */}
   <Page5/>
   <Page6/>
   <Page7/>
   <Page8/>
   <Page9/>
   <Page10/>
<Footer/>
   </>
 
  );
}

export default App;
